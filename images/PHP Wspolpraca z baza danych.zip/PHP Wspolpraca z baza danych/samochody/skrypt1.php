<!DOCTYPE html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<title>Dodaj klienta</title>
	<link rel="stylesheet" href="css/arkusz.css">
</head>
<body>
<?php
	
	

?>
</body>
</html>
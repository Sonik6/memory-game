<?php

	try {
		
		require_once "dbconnect.php";
		
		if ($c->connect_errno) 
		{
			throw new Exception($c->error);
		}
		else 
		{
	
			$c->set_charset("utf8");
			$q = "SELECT DISTINCT marka FROM auta";	
			$result = $c->query($q);
			
			while($row = mysqli_fetch_array($result))
			{
				echo '<option value="'.$row[0].'">'.$row["marka"].'</option>';
			}
			
			$result->free();
		}
	}
	catch(Exception $error) 
	{
		echo "Problemy z odczytem danych!";
	}
?>
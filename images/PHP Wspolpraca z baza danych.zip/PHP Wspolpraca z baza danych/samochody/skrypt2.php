<!DOCTYPE html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<title>Dodaj auto</title>
	<link rel="stylesheet" href="css/arkusz.css">
</head>
<body>
	<form action="skrypt2.php" method="post">
		
		<div>
		
			<label> 
				Marka: <input type="text" name="marka">
			</label>
			
			<label> 
				Model: <input type="text" name="model">
			</label>
			
			<label> 
				Przebieg: <input type="number" name="przebieg">
			</label>
		
		</div>
		<div>
		
			<label for="rocznik"> Rocznik: </label>
			<select name="rocznik" id="rocznik">
				<option value="2021">2021</option>
				<option value="2020">2020</option>
				<option value="2019">2019</option>
				<option value="2018">2018</option>
				<option value="2017">2017</option>
				<option value="2016">2016</option>
				<option value="2015">2015</option>
				<option value="2014">2014</option>
				<option value="2013">2013</option>
				<option value="2012">2012</option>
				<option value="2011">2011</option>
				<option value="2010">2010</option>
				<option value="2009">2009</option>
				<option value="2008">2008</option>
				<option value="2007">2007</option>
				<option value="2006">2006</option>
				<option value="2005">2005</option>
			</select>
			
			<label for="kolor"> Kolor: </label>
			<select name="kolor" id="kolor">
				<option value="white">white</option>
				<option value="yellow">yellow</option>
				<option value="silver">silver</option>
				<option value="green">green</option>
				<option value="blue">blue</option>
				<option value="orange">orange</option>
				<option value="red">red</option>
				<option value="black">black</option>
			</select>
			
		</div>
		
		<input type="submit" value="Dodaj auto">
		
	</form>


<?php

if(isset($_POST['marka']))
{
	
	$marka = $_POST['marka'];
	$model = $_POST['model'];
	$przebieg = $_POST['przebieg'];
	$rocznik = $_POST['rocznik'];
	$kolor = $_POST['kolor'];
	
	
	
}

?>
</body>
</html>
<?php

	$host = "localhost";
	$user = "root";
	$pass = "";
	$db = "samochody";
	
	$c = new mysqli($host, $user, $pass, $db);

?>
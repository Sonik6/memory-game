<!DOCTYPE html>
<html lang="pl">
<head>
	<meta charset="utf-8">
	<title>Wyszukaj auto danej marki</title>
	<link rel="stylesheet" href="css/arkusz.css">
</head>
<body>
	<form action="skrypt3.php" method="post">

		<label for="marka"> Pokaż auta marki: </label>
			
		<select name="marka" id="marka">
		
			<option value="Fiat">Fiat</option>
			<option value="Ford">Ford</option>
			<option value="Opel">Opel</option>

		</select>

		<input type="submit" value="Pokaż samochody">
		
	</form>
	
<?php

if(isset($_POST['marka']))
{
	$marka = $_POST['marka'];

	try {
		
		require_once "dbconnect.php";
		
		if ($c->connect_errno) 
		{
			throw new Exception($c->error);
		}
		else 
		{	
			$c->set_charset("utf8");
			
			$q = "SELECT marka, model, przebieg, rocznik, kolor FROM auta WHERE marka='$marka'";
			
			$c->query($q);
			
			$c->close();
		}

	}
	catch(Exception $error) 
	{
		echo "Problemy z odczytem danych!";
	}
}
	
?>
</body>
</html>